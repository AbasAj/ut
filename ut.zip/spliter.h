char **spliter(char str1[100]);
char **spliter(char str1[100])
{
    int i, j = 0, ctr = 0;
    char **newString = (char **)malloc(10 * sizeof(char *));
    for (i = 0; i < 10; i++)
        newString[i] = (char *)malloc(10 * sizeof(char));
    for (i = 0; i <= (strlen(str1)); i++)
    {
        // if space or NULL found, assign NULL into newString[ctr]
        if (str1[i] == ' ' || str1[i] == '\0')
        {
            newString[ctr][j] = '\0';
            ctr++; // for next word
            j = 0; // for next word, init index to 0
        }
        else
        {
            newString[ctr][j] = str1[i];
            j++;
        }
    }
    return newString;
}