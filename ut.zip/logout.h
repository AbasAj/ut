void logout(int *value);
void logout(int *value)
{
    (*value) = 0;
}