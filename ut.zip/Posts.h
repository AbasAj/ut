typedef struct __Post__
{
    char *Content;
    int like;
    int Post_Id;
    char *Acc_Name;
    struct __Post__ *next;
} Post;