int check_User(Account * head, char *User_name);
int check_User(Account * head, char *User_name)
{
    if(head==NULL)
        return 1;
    for(head; head->next!=NULL;head=head->next)
    {
        if(strcmp(head->User_Name ,User_name)==0)
            return 0;
    }
    return 1;
}