void post(Post **head_ref, char *mohtava, char *name, int *post_id);
void post(Post **head_ref, char *mohtava, char *name, int *post_id)
{
    Post *new_node = (Post *)malloc(sizeof(Post));
    new_node->Content = (char *)malloc(100*sizeof(char));
    new_node->Acc_Name = (char *)malloc(100*sizeof(char));
    Post *last = *head_ref;
    strcpy(new_node->Content, mohtava);
    strcpy(new_node->Acc_Name, name);
    new_node->Post_Id = *(post_id);
    (*(post_id))++;
    new_node->like = 0;
    new_node->next = NULL;
    if (*head_ref == NULL)
    {
        *head_ref = new_node;
        return;
    }
    while (last->next != NULL)
        last = last->next;

    last->next = new_node;
    return;
}