typedef struct __Account__
{
    char *User_Name;
    char *Password;
    struct __Account__ *next;
} Account;