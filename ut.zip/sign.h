int Sign(Account **head_ref, char *User_name, char *Password);
int Sign(Account **head_ref, char *User_name, char *Password)
{
    Account *new_node = (Account *)malloc(sizeof(Account));
    new_node->User_Name = (char *)malloc(100*sizeof(char));
    new_node->Password = (char *)malloc(100*sizeof(char));
    Account *last = *head_ref;
    if(check_User(*head_ref,User_name)==0)
    {
        printf("\nThis User Exist Please Choose Another Name \n");
        return 0;
    }
    if(check_User(*head_ref,User_name)==1)
    {
        strcpy(new_node->User_Name, User_name);
        strcpy(new_node->Password, Password);
        printf("\nSignup is Succes\n");
    }
    new_node->next = NULL;
    if (*head_ref == NULL)
    {
        *head_ref = new_node;
        return 1;
    }
    while (last->next != NULL)
        last = last->next;

    last->next = new_node;
    return 1;
}