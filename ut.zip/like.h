void likes(Post **head_ref, int post_id);
void likes(Post **head_ref, int post_id)
{
    Post *last = *head_ref;
    while (post_id != last->Post_Id)
    {
        last = last->next;
    }
    if (last->Post_Id == post_id)
        last->like++;
}