#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//---------------------------
typedef struct __Account__
{
    char *User_Name;
    char *Password;
    struct __Account__ *next;
} Account;
//---------------------------
typedef struct __Post__
{
    char *Content;
    int like;
    int Post_Id;
    char *Acc_Name;
    struct __Post__ *next;
} Post;
//---------------------------this function for split a words
char **spliter(char str1[100])
{
    int i, j = 0, ctr = 0;
    char **newString = (char **)malloc(10 * sizeof(char *));
    for (i = 0; i < 10; i++)
        newString[i] = (char *)malloc(10 * sizeof(char));
    for (i = 0; i <= (strlen(str1)); i++)
    {
        // if space or NULL found, assign NULL into newString[ctr]
        if (str1[i] == ' ' || str1[i] == '\0')
        {
            newString[ctr][j] = '\0';
            ctr++; // for next word
            j = 0; // for next word, init index to 0
        }
        else
        {
            newString[ctr][j] = str1[i];
            j++;
        }
    }
    return newString;
}
//---------------------------this function for check
int check_User(Account * head, char *User_name)
{
    if(head==NULL)
        return 1;
    for(head; head->next!=NULL;head=head->next)
    {
        if(strcmp(head->User_Name ,User_name)==0)
            return 0;
    }
    return 1;
}
//---------------------------this function for signup
int Sign(Account **head_ref, char *User_name, char *Password)
{
    Account *new_node = (Account *)malloc(sizeof(Account));
    new_node->User_Name = (char *)malloc(100*sizeof(char));
    new_node->Password = (char *)malloc(100*sizeof(char));
    Account *last = *head_ref;
    if(check_User(*head_ref,User_name)==0)
    {
        printf("\nThis User Exist Please Choose Another Name \n");
        return 0;
    }
    if(check_User(*head_ref,User_name)==1)
    {
        strcpy(new_node->User_Name, User_name);
        strcpy(new_node->Password, Password);
        printf("\nSignup is Succes\n");
    }
    new_node->next = NULL;
    if (*head_ref == NULL)
    {
        *head_ref = new_node;
        return 1;
    }
    while (last->next != NULL)
        last = last->next;

    last->next = new_node;
    return 1;
}
//---------------------------this function for post
void post(Post **head_ref, char *mohtava, char *name, int *post_id)
{
    Post *new_node = (Post *)malloc(sizeof(Post));
    new_node->Content = (char *)malloc(100*sizeof(char));
    new_node->Acc_Name = (char *)malloc(100*sizeof(char));
    Post *last = *head_ref;
    strcpy(new_node->Content, mohtava);
    strcpy(new_node->Acc_Name, name);
    new_node->Post_Id = *(post_id);
    (*(post_id))++;
    new_node->like = 0;
    new_node->next = NULL;
    if (*head_ref == NULL)
    {
        *head_ref = new_node;
        return;
    }
    while (last->next != NULL)
        last = last->next;

    last->next = new_node;
    return;
}
//---------------------------this function for like post of player
void likes(Post **head_ref, int post_id)
{
    Post *last = *head_ref;
    while (post_id != last->Post_Id)
    {
        last = last->next;
    }
    if (last->Post_Id == post_id)
        last->like++;
}
//---------------------------this function for logout from acc
void logout(int *value)
{
    (*value) = 0;
}
//---------------------------this function for delet a post from acc
void delet(Post **head_ref, int post_id , char *name)
{
    Post *hasan = *head_ref, *prev;
    if (hasan != NULL && hasan->Post_Id == post_id)
    {
        if(strcmp(hasan->Acc_Name , name)==0)
        {
            *head_ref = hasan->next;
            free(hasan);
        }
        return;
    }
    while (hasan != NULL && hasan->Post_Id != post_id)//&& strcmp(hasan->Acc_Name , name)==0
    {
        prev = hasan;
        hasan = hasan->next;
    }
    if (hasan == NULL)
        return;
    if(strcmp(hasan->Acc_Name , name)==0)
    {
        prev->next = hasan->next;
        free(hasan);
    }
    if(strcmp(hasan->Acc_Name , name)!=0)
    {
        printf("\nYou dont have Permission to delete this post\n");
    }
}
//---------------------------this function show info of player 
void info(Account *node, Post *node1)
{
    printf("\nThe User name of Acc is :\t%s\n", node->User_Name);
    printf("Password of This acc is \t %s\n", node->Password);
    printf("This is a list of Post From User \n\n");
    while (node1->next != NULL)
    {
        if (strcmp(node1->Acc_Name, node->User_Name) == 0)
        {
            printf("\n----------------------\n");
            printf("The Post with id %d\n ", node1->Post_Id );
            printf("The  content of this post is %s\n", node1->Content);
            printf("number of like is %d\n",node1->like);
        }
        node1 = node1->next;
    }
    printf("\n----------------------\n");
    printf("The Post with id %d\n ", node1->Post_Id );
    printf("The  content of this post is %s\n", node1->Content);
    printf("number of like is %d\n",node1->like);
}
//---------------------------this function find user between another user 
void Find_User(char *name, Account *head, Post *headP)
{
    Account *cur = head;
    while (strcmp(cur->User_Name, name) != 0 && cur != NULL)
    {
        cur = cur->next;
    }
    if (cur == NULL)
    {
        printf("\nThis acc is not exist please try again\n");
        return;
    }
    info(cur, headP);
}
//---------------------------this functio is checker  and do with   0 and 1 0 mease false and 1 means true 
int Check_Login(Account *head, char *User_namet, char *Passwordt)
{
    Account *cur = (Account *)malloc(sizeof(Account));
    cur = head;
    while (cur->next != NULL && (strcmp(cur->User_Name, User_namet) != 0 || strcmp(cur->Password, Passwordt) != 0))
    {
        cur = cur->next;
    }
    if (strcmp(cur->User_Name, User_namet) == 0 && strcmp(cur->Password, Passwordt) == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
//---------------------------this function output account *
Account *login(Account *head, char *User_namet, char *Passwordt)
{
    Account *cur = (Account *)malloc(sizeof(Account));
    cur = head;
    while (cur->next != NULL && (strcmp(cur->User_Name, User_namet) != 0 || strcmp(cur->Password, Passwordt) != 0))
    {
        cur = cur->next;
    }
    if (strcmp(cur->User_Name, User_namet) == 0 && strcmp(cur->Password, Passwordt) == 0)
    {
        printf("\n your login is succes %s\n",cur->User_Name);
        return cur;
    }
}
//---------------------------this function substr cut words 
char *Substr(char word[50])
{
    char *result =word+5;
    return result;
}
//---------------------------
void clrscr()
{
    system("cls");
}
//---------------------------this function count the post for check and write in file ** 
int counter_of_post(Post *pos , char * name )
{
    Post * cur;
    int counter=0;
    cur=pos;
    while (cur->next!=NULL)
    {
        if(strcmp(cur->Acc_Name ,name)==0)
        {
            counter++;
        }
        cur=cur->next;
    }
    return counter;
}
//---------------------------two folowing function write info of user into file 
void write_accounts_in_file(FILE **account , Account*head,Post *pos)
{
    Account *cur;
    cur=head;
    char int_str[50];
    for(cur; cur!=NULL;cur=cur->next)
    {
        fprintf(*account,cur->User_Name);
        fprintf(*account,"  ");
        fprintf(*account,cur->Password);
        fprintf(*account,"  ");
        sprintf(int_str,"%d",counter_of_post(pos,cur->User_Name));
        fprintf(*account,int_str);
        fprintf(*account,"\n");
    }
    //this section for replace info in account.txt
}
//---------------------------
void write_post_in_file(FILE **post , Post * pos , Account * acc)
{
    Post * cur_p=pos;
    Account * cur ; 
    char int_str[10];
    for(cur= acc; cur!=NULL ; cur=cur->next )
    {
        for(cur_p=pos ; cur_p!=NULL ; cur_p=cur_p->next)
        {
            if(strcmp(cur_p->Acc_Name ,cur->User_Name)==0)
            {
                sprintf(int_str,"%d",cur_p->like);
                fprintf(*post ,cur->User_Name );
                fprintf(*post , "   ");
                fprintf(*post, cur_p->Content);
                fprintf(*post , "   ");
                fprintf(*post, int_str);
                fprintf(*post ,"\n");
            }
        }
        cur_p=pos;
    }
}
//---------------------------this is control app 
void structure_App(Account *head, Post *head_of_P, int *like, int *post_id,FILE ** account,FILE ** posts_of_user)
{
    char *APP=(char *)malloc(100*sizeof(char));
    Account *cur;
    int two_flag = 1;// for go to second while
    while (strcmp(spliter(APP)[0], "EXIT") != 0)
    {
        printf("\nHello welcome to App please first Signup of login and after Signup use app\n\t\t*********************************\n\nyour command:\t");
        gets(APP);
        //APP="signup hasan salami";
        if(strcmp(spliter(APP)[0], "signup") == 0)
        {
            while (Sign(&head, spliter(APP)[1], spliter(APP)[2])==0)
            {
                gets(APP);
            }
            cur = login(head, spliter(APP)[1], spliter(APP)[2]);
            two_flag=1;
        }
        if(strcmp(spliter(APP)[0], "login") == 0)
        {
            while (Check_Login(head,spliter(APP)[1],spliter(APP)[2])==0)
            {
                printf("\nYour Password is wrong Please Try Again\n");
                gets(APP);
            }
            cur = login(head, spliter(APP)[1], spliter(APP)[2]);
            two_flag=1;
        }
        // until this place user signup and login to acc
        while (two_flag)
        {
            gets(APP);
            //APP="post hasan hsatam";
            if (strcmp(spliter(APP)[0], "signup") == 0)
                printf("\nyou are now in your acc please send other command \n");
            if (strcmp(spliter(APP)[0], "login") == 0)
                printf("\nyou are now in your acc please send other command \n");
            if(strcmp(spliter(APP)[0],"post")==0)
            {
                post(&head_of_P,Substr(APP),cur->User_Name,post_id);
            }
            if (strcmp(spliter(APP)[0], "likes") == 0)
            {
                printf("\n%d\n",atoi(spliter(APP)[2]));
                likes(&head_of_P, atoi(spliter(APP)[2]));
            }
            if (strcmp(spliter(APP)[0], "logout") == 0)
                logout(&two_flag);
            if (strcmp(spliter(APP)[0], "delet") == 0)
                delet(&head_of_P, atoi(spliter(APP)[1]),cur->User_Name);
            if (strcmp(spliter(APP)[0], "info") == 0)
                info(cur, head_of_P);
            if (strcmp(spliter(APP)[0], "find_user") == 0)
                Find_User(spliter(APP)[1], head, head_of_P);
            if (strcmp(spliter(APP)[0], "find_user") != 0 && strcmp(spliter(APP)[0], "info") != 0 && strcmp(spliter(APP)[0], "delet") != 0 && strcmp(spliter(APP)[0], "logout") != 0 && strcmp(spliter(APP)[0], "likes") != 0 &&strcmp(spliter(APP)[0],"post")!=0 ) 
                printf("\nPlease Enter a correct command\n")  ;
        }
        clrscr();
    }
    write_accounts_in_file(account,head,head_of_P);
    write_post_in_file(posts_of_user,head_of_P,head);
}
//---------------------------
int main()
{
    FILE *fp;
    FILE *post_and_user;
    post_and_user=fopen("Post.txt","w");
    fp=fopen("Accounts.txt","w");
    fprintf(fp,"The list of User :\n");
    int like = 0, post_id = 0;
    Account *head = NULL;
    Sign(&head, "CodeSystem", "CodeSystem");
    Post *head_for_post = NULL;
    post(&head_for_post, "CodeSystem", "CodeSystem", &post_id);
    //clrscr();
    structure_App(head, head_for_post, &like, &post_id,&fp,&post_and_user);
    fclose(fp);
    fclose(post_and_user);
    return 0;
}

